SampHost Brasil - Painel Simulado (Frontend + Backend)
--------------------------------------------------------
Conteúdo:
- frontend/ (site estático)
- backend/ (Node.js + Express API que simula criação e controle do servidor)
- render.yaml and Dockerfile included for deployment guidance

Testar localmente (desktop):
1) Abra terminal, vá para backend/:
   cd backend
   npm install
   node index.js
2) Acesse http://localhost:3000/ no navegador. Demo: admin@samphost.com / adminpass

Como publicar no Render.com (pelo celular):
1) Crie repositório no GitHub (nome: samp-server).
2) Faça push dos arquivos deste pacote (tudo na raiz).
3) No Render, crie um Web Service ligado ao repositório.
4) Build command: npm install --prefix backend
5) Start command: node backend/index.js
6) Deploy; o frontend será servido pelo backend estático.

Observações:
- Este backend é simulado; para controlar servidores SAMP reais substitua a lógica de /api/server/* por integrações com seu VPS (SSH, Pterodactyl API, etc.).
- Não inclui binários SAMP (por políticas). Vou te enviar os comandos separados para instalar SAMP no seu VPS.
