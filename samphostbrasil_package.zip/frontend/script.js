const apiBase = "/api"; // backend path (when deployed backend and frontend together)
const $ = s => document.querySelector(s);
let token = localStorage.getItem("sh_token") || null;

function openModal(){ document.getElementById("modal").classList.remove("hidden"); }
function closeModal(){ document.getElementById("modal").classList.add("hidden"); }

document.getElementById("btn-login").addEventListener("click", openModal);
document.getElementById("close").addEventListener("click", closeModal);
document.getElementById("show-register").addEventListener("click", ()=>{ document.getElementById("modal-title").textContent='Registrar'; document.getElementById("form-login").classList.add('hidden'); document.getElementById("form-register").classList.remove('hidden'); });
document.getElementById("show-login").addEventListener("click", ()=>{ document.getElementById("modal-title").textContent='Entrar'; document.getElementById("form-register").classList.add('hidden'); document.getElementById("form-login").classList.remove('hidden'); });

async function request(path, opts={}){
  const headers = opts.headers||{};
  if(token) headers['x-auth'] = token;
  const res = await fetch(apiBase+path, {...opts, headers});
  return res.json().catch(()=>({ok:false}));
}

document.getElementById("form-login").addEventListener("submit", async (e)=>{
  e.preventDefault();
  const email = document.getElementById("email").value.trim().toLowerCase();
  const pass = document.getElementById("pass").value;
  const res = await request("/login", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({email,pass})});
  if(!res.ok){ alert(res.message||"Erro"); return; }
  token = res.token; localStorage.setItem("sh_token", token); closeModal(); loadServer();
});

document.getElementById("form-register").addEventListener("submit", async (e)=>{
  e.preventDefault();
  const name = document.getElementById("rname").value.trim();
  const email = document.getElementById("remail").value.trim().toLowerCase();
  const pass = document.getElementById("rpass").value;
  const res = await request("/register", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({name,email,pass})});
  if(!res.ok){ alert(res.message||"Erro"); return; }
  token = res.token; localStorage.setItem("sh_token", token); closeModal(); loadServer();
});

document.getElementById("btn-create").addEventListener("click", async ()=>{
  if(!token){ openModal(); return; }
  const name = prompt("Nome do servidor:","BRASIL SUPREME ROLEPLAY");
  const gm = prompt("Gamemode (base/rpg):","rpg");
  const res = await request("/server/create", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({name, gamemode:gm})});
  if(!res.ok){ alert(res.message||"Erro"); return; }
  alert("Servidor criado: "+res.server.id);
  loadServer();
});

document.getElementById("start").addEventListener("click", async ()=>{ await request("/server/start", {method:"POST"}); loadServer(); });
document.getElementById("stop").addEventListener("click", async ()=>{ await request("/server/stop", {method:"POST"}); loadServer(); });
document.getElementById("restart").addEventListener("click", async ()=>{ await request("/server/restart", {method:"POST"}); loadServer(); });
document.getElementById("btn-status").addEventListener("click", async ()=>{ loadServer(true); });

async function loadServer(showAlert=false){
  const res = await request("/server");
  if(!res.ok){ if(showAlert) alert(res.message||"Nenhum servidor"); return; }
  const s = res.server;
  document.getElementById("server-card").hidden = false;
  document.getElementById("s-name").textContent = s.name;
  document.getElementById("s-ip").textContent = s.ip;
  document.getElementById("s-port").textContent = s.port;
  document.getElementById("s-status").textContent = s.status;
  document.getElementById("s-gm").textContent = s.gamemode;
  document.getElementById("s-players").textContent = s.players;
  document.getElementById("console").textContent = (s.console||[]).join("\n") || "Console: sem atividade";
}
window.addEventListener("load", ()=>{ if(localStorage.getItem("sh_token")) loadServer(); });
