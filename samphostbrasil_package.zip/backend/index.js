const express = require('express');
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');
const DATA = path.join(__dirname,'data.json');
function load(){ try{return JSON.parse(fs.readFileSync(DATA))}catch(e){return {users:{},sessions:{},server:null}} }
function save(d){ fs.writeFileSync(DATA, JSON.stringify(d,null,2)) }
let db = load();

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname,'../frontend')));

function auth(req,res,next){
  const token = req.headers['x-auth'];
  if(!token || !db.sessions[token]) return res.json({ok:false, message:'Não autenticado'});
  req.user = db.sessions[token];
  next();
}

app.post('/api/register',(req,res)=>{
  const {name,email,pass} = req.body;
  if(!email||!pass||!name) return res.json({ok:false,message:'Preencha todos os campos'});
  if(db.users[email]) return res.json({ok:false,message:'Email já existe'});
  db.users[email] = {name,email,pass};
  const token = uuidv4();
  db.sessions[token] = {email,name};
  save(db);
  res.json({ok:true, token});
});
app.post('/api/login',(req,res)=>{
  const {email,pass} = req.body;
  if(!email||!pass) return res.json({ok:false,message:'Preencha todos os campos'});
  const u = db.users[email];
  if(!u || u.pass !== pass) return res.json({ok:false,message:'Credenciais inválidas'});
  const token = uuidv4();
  db.sessions[token] = {email,name:u.name};
  save(db);
  res.json({ok:true, token});
});

app.get('/api/server',(req,res)=>{
  if(!db.server) return res.json({ok:false,message:'Nenhum servidor criado'});
  res.json({ok:true, server:db.server});
});
app.post('/api/server/create',auth,(req,res)=>{
  const {name,gamemode} = req.body;
  if(!name) return res.json({ok:false,message:'Nome requerido'});
  db.server = { id: uuidv4(), name, gamemode: gamemode||'base', ip:'0.0.0.0', port:7777, status:'offline', players:0, console:[] };
  db.server.console.push(`[${new Date().toLocaleString()}] Servidor criado: ${name}`);
  save(db);
  res.json({ok:true, server:db.server});
});
app.post('/api/server/start',auth,(req,res)=>{
  if(!db.server) return res.json({ok:false,message:'Nenhum servidor'});
  db.server.status = 'online';
  db.server.ip = 'play.samphost.local';
  db.server.players = Math.floor(Math.random()*40);
  db.server.console.push(`[${new Date().toLocaleString()}] Servidor iniciado`);
  save(db);
  res.json({ok:true});
});
app.post('/api/server/stop',auth,(req,res)=>{
  if(!db.server) return res.json({ok:false,message:'Nenhum servidor'});
  db.server.status = 'offline';
  db.server.players = 0;
  db.server.console.push(`[${new Date().toLocaleString()}] Servidor parado`);
  save(db);
  res.json({ok:true});
});
app.post('/api/server/restart',auth,(req,res)=>{
  if(!db.server) return res.json({ok:false,message:'Nenhum servidor'});
  db.server.console.push(`[${new Date().toLocaleString()}] Reiniciando servidor...`);
  db.server.status = 'online';
  db.server.players = Math.floor(Math.random()*30);
  save(db);
  res.json({ok:true});
});

app.get('/api/health',(req,res)=>res.json({ok:true}));

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log('Backend running on',PORT));

if(!fs.existsSync(DATA)) save({users:{'admin@samphost.com':{name:'Admin',email:'admin@samphost.com',pass:'adminpass'}},sessions:{},server:null});
